﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NoteBookConsoleApp
{
    internal class NotebookLogger
    {
        private Notebook trackedNotebook;
        private bool logging = true;

        public NotebookLogger(Notebook trackedNotebook)
        {
            this.trackedNotebook = trackedNotebook;
            Attach();
        }
        private void PrintAdded(string typeItemAdded)
        { 
            Console.WriteLine($"{typeItemAdded} was added to the notebook.");
        }
        private void PrintDeleted(string idOfDeleted)
        {
            if(idOfDeleted != "")
            {
                Console.WriteLine($"Item {idOfDeleted} was deleted from the notebook.");
            }
            else
            {
                Console.WriteLine("Everything was deleted from the notebook.");
            }
        }
        private void IncorrectCommand(string messageToPrint)
        {
            Console.WriteLine($"Bad Command: {messageToPrint}");
        }
        public void ToggleLoggin(bool isLoggingOn)
        { 
        }
        private void Attach()
        {
            trackedNotebook.ItemAdded += PrintAdded;
            trackedNotebook.ItemRemoved += PrintDeleted;
            trackedNotebook.InputBadCommand += IncorrectCommand;
        }
        private void Detach()
        {
            trackedNotebook.ItemAdded -= PrintAdded;
            trackedNotebook.ItemRemoved -= PrintDeleted;
            trackedNotebook.InputBadCommand -= IncorrectCommand;
        }
    }
}
